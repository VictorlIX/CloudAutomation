import imaplib, email

user = 'victor.ponce@cbts.com'
password = 'Stephanie16'
imap_url = 'imap-mail.outlook.com'
print("hjhfg")
def get_body(msg):
        if msg.is_multipart():
                return get_body(msg.get_payload(0))
        else:
                return msg.get_payload(None,True)        
con = imaplib.IMAP4_SSL(imap_url)
con.login(user,password)
lists = con.list()
print(lists)
con.select('Inbox')

rest, data = con.fetch(b'1', '(RFC822)')
raw = email.message_from_bytes(data[0][1])
print(get_body(raw))

#WEBHOOK

webhook = "https://hooks.slack.com/services/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"